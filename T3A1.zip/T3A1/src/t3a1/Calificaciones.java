package t3a1;
import java.util.Scanner;



public class Calificaciones {
    private String nombre, apellidoPaterno, apellidoMaterno, grupo, 
            carrera, nombreAsignatura;
    private int calificacion, calificacion2;
    private double promedio;

  
    public Calificaciones(){ //Metodo constructor vacio
    }
    public Calificaciones(String nombre, String apellidoPaterno, String apellidoMaterno, String grupo, String carrera, String nombreAsignatura, int calificacion,int calificacion2, double promedio) {
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.grupo = grupo;
        this.carrera = carrera;
        this.nombreAsignatura = nombreAsignatura;
        this.calificacion = calificacion;
        this.calificacion2 = calificacion2;
        this.promedio = promedio;
        
    }

    @Override
    public String toString() {
        return "Calificaciones{" + "nombre=" + nombre + ", apellidoPaterno=" + 
                apellidoPaterno + ", apellidoMaterno=" + apellidoMaterno + 
                ", grupo=" + grupo + ", carrera=" + carrera + ", nombreAsignatura=" + nombreAsignatura +
                ", calificacion=" + calificacion + ", promedio=" + promedio + '}';
    }
    
    
    
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getNombreAsignatura() {
        return nombreAsignatura;
    }

    public void setNombreAsignatura(String nombreAsignatura) {
        this.nombreAsignatura = nombreAsignatura;
    }

    public int getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(int calificacion) {
        this.calificacion = calificacion;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
       
        promedio = (calificacion*calificacion2) /2;
        
        this.promedio = promedio;     

    }
    

    public int getCalificacion2() {
        return calificacion2;
    }

    public void setCalificacion2(int calificacion2) {
        this.calificacion2 = calificacion2;
    }
    
    
    
}
