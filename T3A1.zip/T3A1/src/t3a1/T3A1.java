
package t3a1;

import java.util.Scanner;

public class T3A1 {


     
    public static void main(String[] args) {
     procesar();
     
    }
    public static void procesar() {
        Scanner scanner = new Scanner (System.in);
       Calificaciones calificaciones = new Calificaciones();
       
        System.out.println("Nombre");
        String nombre = scanner.nextLine();
        calificaciones.setNombre(nombre);
        
        System.out.println("Apellido Paterno");
        String apellidoPaterno = scanner.nextLine();
        calificaciones.setApellidoPaterno(apellidoPaterno);
        
        System.out.println("Apellido Materno");
        String apellidoMaterno = scanner.nextLine();
        calificaciones.setApellidoMaterno(apellidoMaterno);
        
        System.out.println("Grupo");
        String grupo = scanner.nextLine();
        calificaciones.setGrupo(grupo);
        
        System.out.println("Carrera");
        String carrera = scanner.nextLine();
        calificaciones.setCarrera(carrera);
        
        System.out.println("Asignatura");
        String nombreAsignatura = scanner.nextLine();
        calificaciones.setNombreAsignatura(nombreAsignatura);
        
        System.out.println("Calificacion");
        int calificacion = scanner.nextInt();
        calificaciones.setCalificacion(calificacion);
        
        System.out.println("Calificacion 2");
        int calificacion2 = scanner.nextInt();
        calificaciones.setCalificacion2(calificacion2);
        
    
      
        
        System.out.println(calificaciones.toString());
    }
    
}
